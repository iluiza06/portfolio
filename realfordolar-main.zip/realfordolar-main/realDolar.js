const real = document.getElementById("real");
const Convert = document.getElementById("btn");
const resultado = document.getElementById("resultado");

function conversao() {
    const taxaCambio = 5.67

    const valorReal = parseFloat(real.value);

    if (isNaN(valorReal) || valorReal <= 0) {
        resultado.innerHTML = 'Por favor, insira um valor válido!';
        return;
    }

    const valorDolar = (valorReal / taxaCambio).toFixed(2);
    resultado.innerHTML = `Valor em Dólar $${valorDolar}`;
}