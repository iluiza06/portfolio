async function connect() {

    if(global.connection)
        return global.connection.connect();

    const { Pool } = require('pg');
    const pool = new Pool({
        connectionString: process.env.CONNECTION_STRING
    });

    const client = await pool.connect();

    client.release();

    global.connection = pool;

    return pool.connect();
}


connect();

async function selectServicosAcordosPermissionarios(startDate, endDate){
    const query = "SELECT gr.ds_grupo_receita AS receita, to_char(tit.dt_pagamento, 'dd/mm/yyyy') AS data, sum(tit.vl_pago) AS valor, tit.id_titulo as ident "
                + "FROM tb_titulo AS tit "
                + "INNER JOIN tb_item_faturamento AS ifat ON ifat.id_titulo = tit.id_titulo "
                + "LEFT JOIN tb_servico AS s ON s.id_servico = ifat.id_servico "
                + "INNER JOIN tb_subgrupo_servico AS ss ON ss.id_subgrupo_servico = s.id_subgrupo_servico "
                + "LEFT JOIN tb_grupo_receita AS gr ON gr.id_grupo_receita = ifat.id_grupo_receita "
                + "LEFT JOIN tb_natureza_contabil AS nc ON nc.id_natureza_contabil = ifat.id_natureza_contabil "
                + "WHERE tit.id_situacao_titulo != 1 AND tit.id_situacao_titulo != 2 AND tit.id_situacao_titulo != 5 AND tit.id_situacao_titulo != 8 AND tit.dt_pagamento BETWEEN $1 AND $2 AND ifat.id_tipo_lancamento IS NULL "
                + "GROUP BY receita, data, ident " 
                + "UNION "
                + "SELECT gr.ds_grupo_receita AS receita, TO_CHAR(tit.dt_pagamento, 'dd/mm/yyyy') AS data, sum(tit.vl_pago) AS valor, tit.id_titulo as ident "
                + "FROM tb_titulo AS tit "
                + "INNER JOIN tb_item_faturamento AS ifat ON ifat.id_titulo = tit.id_titulo "
                + "LEFT JOIN tb_permissao AS p ON p.id_permissao = ifat.id_permissao "
                + "LEFT JOIN tb_grupo_receita AS gr ON gr.id_grupo_receita = ifat.id_grupo_receita "
                + "LEFT JOIN tb_natureza_contabil AS nc ON nc.id_natureza_contabil = ifat.id_natureza_contabil "
                + "WHERE tit.id_situacao_titulo != 1 AND tit.id_situacao_titulo != 2 AND tit.id_situacao_titulo != 5 AND tit.id_situacao_titulo != 8 AND tit.dt_pagamento BETWEEN $1 AND $2 AND ifat.id_tipo_lancamento IS NULL "
                + "GROUP BY receita, data, ident "
                + "UNION "
                + "SELECT gr.ds_grupo_receita AS receita, TO_CHAR(tit.dt_pagamento, 'dd/mm/yyyy') AS data, sum(tit.vl_pago) AS valor, tit.id_titulo as ident " 
                + "FROM tb_titulo AS tit "
                + "INNER JOIN tb_item_faturamento AS ifat ON ifat.id_titulo = tit.id_titulo "
                + "LEFT JOIN tb_acordo AS aco ON aco.id_acordo = ifat.id_acordo " 
                + "LEFT JOIN tb_grupo_receita AS gr ON gr.id_grupo_receita = ifat.id_grupo_receita " 
                + "LEFT JOIN tb_natureza_contabil AS nc ON nc.id_natureza_contabil = ifat.id_natureza_contabil "
                + "WHERE tit.id_situacao_titulo != 1 AND tit.id_situacao_titulo != 2 AND tit.id_situacao_titulo != 5 AND tit.id_situacao_titulo != 8 AND tit.dt_pagamento BETWEEN $1 AND $2 AND ifat.id_tipo_lancamento IS NULL "
                + "GROUP BY receita, data, ident "
                + "UNION "
                + "SELECT gr.ds_grupo_receita AS receita, TO_CHAR(tit.dt_pagamento, 'dd/mm/yyyy') AS data, sum(tit.vl_pago) AS valor, tit.id_titulo as ident "
                + "FROM tb_titulo AS tit " 
                + "INNER JOIN tb_item_faturamento AS ifat ON ifat.id_titulo = tit.id_titulo "
                + "LEFT JOIN tb_grupo_receita AS gr ON gr.id_grupo_receita = ifat.id_grupo_receita "
                + "WHERE tit.id_situacao_titulo != 1 "
                + "AND tit.id_situacao_titulo != 2 "
                + "AND tit.id_situacao_titulo != 5 "
                + "AND tit.id_situacao_titulo != 8 "
                + "AND tit.dt_pagamento BETWEEN $1 and $2 "
                + "AND ifat.id_tipo_lancamento IS NULL "
                + "AND ifat.id_servico is null "
                + "AND ifat.id_acordo is null "
                + "AND ifat.id_permissao is null "
                + "AND ifat.id_evento_inscricao is not null "
                + "GROUP BY receita, data, ident " 
                + "ORDER BY data, receita, ident";

    const client = await connect();
    const res = await client.query(query, [startDate, endDate]);
    return res.rows;
}

async function selectContaBancaria(startDate, endDate){ 
    const query = "SELECT TO_CHAR(dt_pagamento, 'dd/mm/yyyy') AS pagamento, COUNT(dt_baixa) AS quant, "
                + "SUM(vl_pago) AS valor FROM tb_titulo "
                + "WHERE dt_pagamento BETWEEN $1 AND $2 "
                + "GROUP BY pagamento "
                + "ORDER BY pagamento";
    const client = await connect();
    const res = await client.query(query, [startDate, endDate]);
    return res.rows;

}


async function selectTaxa(startDate, endDate, name, cpfcnpj){ 
    
    const query = "SELECT s.id_servico AS numerotaxa, gs.ds_grupo_servico AS descricao, u.nm_usuario AS nomesolicitante, enu.ds_endereco AS endereco, enu.ds_bairro AS bairro, sb.vl_cobranca AS valor, uc.ds_unidade_1 AS descricaounidade, us.nm_usuario AS nomeapontador, "
                                    +"tt.vl_pago AS valorpago, tt.vl_titulo AS valortitulo, s.ds_observacao_geral AS obs, sb.ds_subgrupo_servico AS descricaosub, s.dt_previsao_execucao AS data, enu.ds_complemento AS complemento, s.in_publico AS publico, s.in_isento AS isento, "
                                    +"s.qt_unidade_cobranca AS quantidade, s.dt_cadastro AS datacadastro, s.dt_finalizacao AS datafinalizacao, u.nr_cpf_cnpj AS cpfcnpj "
                                    +"FROM tb_servico AS s "
                                    +"INNER JOIN tb_item_faturamento AS itf ON s.id_servico = itf.id_servico "
									+"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                                    +"INNER JOIN tb_usuario AS u ON s.id_usuario = u.id_usuario "
                                    +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                                    +"FROM tb_endereco_usuario "
                                    +"ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                                    +"INNER JOIN tb_usuario AS us ON s.id_usuario_cadastro = us.id_usuario "
                                    +"INNER JOIN tb_subgrupo_servico AS sb ON s.id_subgrupo_servico = sb.id_subgrupo_servico "
                                    +"INNER JOIN tb_grupo_servico AS gs ON sb.id_grupo_servico = gs.id_grupo_servico "
                                    +"INNER JOIN tb_unidade_cobranca AS uc ON sb.id_unidade_cobranca = uc.id_unidade_cobranca "
                                    +"WHERE s.dt_cadastro BETWEEN $1 AND $2 AND ($3 = '' OR u.nm_usuario ILIKE '%' || $3 || '%') AND ($4 = '' OR u.nr_cpf_cnpj LIKE '%' || $4 || '%') "
                                    +"ORDER BY s.id_servico DESC LIMIT 3000"; 
    const client = await connect(); 
    const res = await client.query(query, [startDate, endDate, name, cpfcnpj]);
    return res.rows; 
}


async function selectFinancas(cpfcnpj){ 
    const query = "SELECT tt.id_titulo AS numero, tt.vl_titulo AS valor, tt.nr_nosso_numero AS nossonumero, tt.vl_multa AS multa, tt.vl_juros AS juros, "
                    +"bc.nm_banco AS banco, tt.ds_parcela AS parcela, tt.ds_mes_ano_competencia AS ano_competencia, "
                    +"tt.nr_agencia_cod_cededente AS agencia_tipo, tt.dt_vencimento AS datavencimento, "
                    +"st.ds_situacao_titulo AS situacaotitulo, tt.dt_pagamento AS datapagamento, tt.vl_pago AS valorpago, "
                    +"tt.cd_conta_corrente AS conta, tt.dt_geracao AS datageracao, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf "
                    +"FROM tb_item_faturamento AS itf "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"INNER JOIN tb_situacao_titulo AS st ON tt.id_situacao_titulo = st.id_situacao_titulo "
                    +"INNER JOIN tb_banco AS bc ON bc.cd_banco = SUBSTRING(tt.nr_codigo_barra FROM 1 FOR 3) "
                    +"INNER JOIN tb_permissao AS pm ON itf.id_permissao = pm.id_permissao "
                    +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
                    +"WHERE u.nr_cpf_cnpj = $1 "
                    +"UNION "
                    +"SELECT tt.id_titulo AS numero, tt.vl_titulo AS valor, tt.nr_nosso_numero AS nossonumero, tt.vl_multa AS multa, tt.vl_juros AS juros, "
                    +"bc.nm_banco AS banco, tt.ds_parcela AS parcela, tt.ds_mes_ano_competencia AS ano_competencia, "
                    +"tt.nr_agencia_cod_cededente AS agencia_tipo, tt.dt_vencimento AS datavencimento, "
                    +"st.ds_situacao_titulo AS situacaotitulo, tt.dt_pagamento AS datapagamento, tt.vl_pago AS valorpago, "
                    +"tt.cd_conta_corrente AS conta, tt.dt_geracao AS datageracao, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf "
                    +"FROM tb_item_faturamento AS itf "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"INNER JOIN tb_situacao_titulo AS st ON tt.id_situacao_titulo = st.id_situacao_titulo "
                    +"INNER JOIN tb_banco AS bc ON bc.cd_banco = SUBSTRING(tt.nr_codigo_barra FROM 1 FOR 3) "
                    +"INNER JOIN tb_servico AS s ON itf.id_servico = s.id_servico "
                    +"INNER JOIN tb_usuario AS u ON s.id_usuario = u.id_usuario "
                    +"WHERE u.nr_cpf_cnpj = $1 "
                    +"UNION "
                    +"SELECT tt.id_titulo AS numero, tt.vl_titulo AS valor, tt.nr_nosso_numero AS nossonumero, tt.vl_multa AS multa, tt.vl_juros AS juros, "
                    +"bc.nm_banco AS banco, tt.ds_parcela AS parcela, tt.ds_mes_ano_competencia AS ano_competencia, "
                    +"tt.nr_agencia_cod_cededente AS agencia_tipo, tt.dt_vencimento AS datavencimento, "
                    +"st.ds_situacao_titulo AS situacaotitulo, tt.dt_pagamento AS datapagamento, tt.vl_pago AS valorpago, "
                    +"tt.cd_conta_corrente AS conta, tt.dt_geracao AS datageracao, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf "
                    +"FROM tb_item_faturamento AS itf "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"INNER JOIN tb_situacao_titulo AS st ON tt.id_situacao_titulo = st.id_situacao_titulo "
                    +"INNER JOIN tb_banco AS bc ON bc.cd_banco = SUBSTRING(tt.nr_codigo_barra FROM 1 FOR 3) "
                    +"INNER JOIN tb_acordo AS ac ON itf.id_acordo = ac.id_acordo "
                    +"INNER JOIN tb_usuario AS u ON ac.id_usuario = u.id_usuario "
                    +"WHERE u.nr_cpf_cnpj = $1 "
                    +"UNION "
                    +"SELECT tt.id_titulo AS numero, tt.vl_titulo AS valor, tt.nr_nosso_numero AS nossonumero, tt.vl_multa AS multa, tt.vl_juros AS juros, "
                    +"bc.nm_banco AS banco, tt.ds_parcela AS parcela, tt.ds_mes_ano_competencia AS ano_competencia, "
                    +"tt.nr_agencia_cod_cededente AS agencia_tipo, tt.dt_vencimento AS datavencimento, "
                    +"st.ds_situacao_titulo AS situacaotitulo, tt.dt_pagamento AS datapagamento, tt.vl_pago AS valorpago, "
                    +"tt.cd_conta_corrente AS conta, tt.dt_geracao AS datageracao, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf "
                    +"FROM tb_item_faturamento AS itf "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"INNER JOIN tb_situacao_titulo AS st ON tt.id_situacao_titulo = st.id_situacao_titulo "
                    +"INNER JOIN tb_banco AS bc ON bc.cd_banco = SUBSTRING(tt.nr_codigo_barra FROM 1 FOR 3) "
                    +"INNER JOIN tb_evento_inscricao AS ev ON itf.id_evento_inscricao = ev.id_evento_inscricao "
                    +"INNER JOIN tb_usuario AS u ON ev.id_usuario = u.id_usuario "
                    +"WHERE u.nr_cpf_cnpj = $1 "
                    +"ORDER BY numero DESC LIMIT 3000";
    
    // "SELECT tt.id_titulo AS numero, tt.vl_titulo AS valor, tt.nr_nosso_numero AS nossonumero, tt.vl_multa AS multa, tt.vl_juros AS juros, "
    //                 +"bc.nm_banco AS banco, tt.ds_parcela AS parcela, tt.ds_mes_ano_competencia AS ano_competencia, "
    //                 +"tt.nr_agencia_cod_cededente AS agencia_tipo, tt.dt_vencimento AS datavencimento, "
    //                 +"st.ds_situacao_titulo AS situacaotitulo, tt.dt_pagamento AS datapagamento, tt.vl_pago AS valorpago, "
    //                 +"tt.cd_conta_corrente AS conta, tt.dt_geracao AS datageracao, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf "
    //                 +"FROM tb_item_faturamento AS itf "
    //                 +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
    //                 +"INNER JOIN tb_situacao_titulo AS st ON tt.id_situacao_titulo = st.id_situacao_titulo "
    //                 +"INNER JOIN tb_banco AS bc ON bc.cd_banco = SUBSTRING(tt.nr_codigo_barra FROM 1 FOR 3) "
    //                 +"INNER JOIN tb_permissao AS pm ON itf.id_permissao = pm.id_permissao "
    //                 +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
    //                 +"WHERE u.nr_cpf_cnpj = $1 "
    //                 +"ORDER BY tt.id_titulo DESC LIMIT 3000";
    const client = await connect(); 
    const res = await client.query(query, [cpfcnpj]);
    return res.rows; 
}


async function selectExtrato(cpfcnpj){ 
    const query = "SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
                    +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
                    +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
                    +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
                    +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
                    +"FROM tb_permissao AS pm "
                    +"INNER JOIN tb_item_faturamento AS itf ON pm.id_permissao = itf.id_permissao "
                    +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
                    +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                    +"                FROM tb_endereco_usuario "
                    +"               ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
                    +"UNION "
                    +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
                    +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
                    +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
                    +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
                    +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
                    +"FROM tb_servico AS s "
                    +"INNER JOIN tb_item_faturamento AS itf ON s.id_servico = itf.id_servico "
                    +"INNER JOIN tb_usuario AS u ON s.id_usuario = u.id_usuario "
                    +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                    +"                FROM tb_endereco_usuario "
                    +"                ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
                    +"UNION "
                    +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
                    +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
                    +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
                    +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
                    +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
                    +"FROM tb_acordo AS ac "
                    +"INNER JOIN tb_item_faturamento AS itf ON ac.id_acordo = itf.id_acordo "
                    +"INNER JOIN tb_usuario AS u ON ac.id_usuario = u.id_usuario "
                    +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                    +"                FROM tb_endereco_usuario "
                    +"                ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
                    +"UNION "
                    // +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
                    // +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
                    // +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
                    // +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
                    // +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
                    // +"FROM tb_cdc AS cdc "
                    // +"INNER JOIN tb_ponto AS pt ON cdc.id_cdc = pt.id_cdc_agua "
                    // +"INNER JOIN tb_permissao_ponto AS pmpt ON pt.id_ponto = pmpt.id_ponto "
                    // +"INNER JOIN tb_permissao AS pm ON pmpt.id_permissao = pm.id_permissao "
                    // +"INNER JOIN tb_item_faturamento AS itf ON pm.id_permissao = itf.id_permissao "
                    // +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
                    // +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                    //  +"               FROM tb_endereco_usuario "
                    //  +"               ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                    // +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    // +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
                    // +"UNION "
                    // +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
                    // +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade  "
                    // +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
                    // +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
                    // +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
                    // +"FROM tb_cdc AS cdc "
                    // +"INNER JOIN tb_ponto AS pt ON cdc.id_cdc = pt.id_cdc_energia "
                    // +"INNER JOIN tb_permissao_ponto AS pmpt ON pt.id_ponto = pmpt.id_ponto "
                    // +"INNER JOIN tb_permissao AS pm ON pmpt.id_permissao = pm.id_permissao "
                    // +"INNER JOIN tb_item_faturamento AS itf ON pm.id_permissao = itf.id_permissao "
                    // +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
                    // +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                    // +"               FROM tb_endereco_usuario "
                    // +"                ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                    // +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    // +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
                    // +"UNION "
                    +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
                    +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
                    +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
                    +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
                    +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
                    +"FROM tb_evento_inscricao AS ev "
                    +"INNER JOIN tb_item_faturamento AS itf ON ev.id_evento_inscricao = itf.id_evento_inscricao "
                    +"INNER JOIN tb_usuario AS u ON ev.id_usuario = u.id_usuario "
                    +"INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
                    +"                FROM tb_endereco_usuario "
                    +"                ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
                    +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
                    +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
                    +"ORDER BY datavencimento";
    
    
// "SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
//                     +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
//                     +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
//                     +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
//                     +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
//                     +"FROM tb_permissao AS pm "
//                     +"INNER JOIN tb_item_faturamento AS itf ON pm.id_permissao = itf.id_permissao "
//                     +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
//                     + "INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
//                     + "                 FROM tb_endereco_usuario "
//                     + "                 ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
//                     +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
//                     +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
//                     +"UNION "
//                     +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
//                     +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
//                     +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
//                     +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
//                     +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
//                     +"FROM tb_servico AS s "
//                     +"INNER JOIN tb_item_faturamento AS itf ON s.id_servico = itf.id_servico "
//                     +"INNER JOIN tb_usuario AS u ON s.id_usuario = u.id_usuario "
//                     + "INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
//                     + "                 FROM tb_endereco_usuario "
//                     + "                 ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
//                     +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
//                     +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
//                     +"UNION "
//                     +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
//                     +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
//                     +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
//                     +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
//                     +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
//                     +"FROM tb_taxa AS tx "
//                     +"INNER JOIN tb_item_faturamento AS itf ON tx.id_taxa = itf.id_taxa "
//                     +"INNER JOIN tb_servico AS s ON itf.id_servico = s.id_servico "
//                     +"INNER JOIN tb_usuario AS u ON s.id_usuario = u.id_usuario "
//                     + "INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
//                     + "                 FROM tb_endereco_usuario "
//                     + "                 ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
//                     +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
//                     +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
//                     +"UNION "
//                     +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
//                     +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
//                     +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
//                     +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
//                     +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
//                     +"FROM tb_acordo AS ac "
//                     +"INNER JOIN tb_item_faturamento AS itf ON ac.id_acordo = itf.id_acordo "
//                     +"INNER JOIN tb_usuario AS u ON ac.id_usuario = u.id_usuario "
//                     + "INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
//                     + "                 FROM tb_endereco_usuario "
//                     + "                 ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
//                     +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
//                     +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
//                     +"UNION "
//                     +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
//                     +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
//                     +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
//                     +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
//                     +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
//                     +"FROM tb_cdc AS cdc "
//                     +"INNER JOIN tb_ponto AS pt ON cdc.id_cdc = pt.id_cdc_agua "
//                     +"INNER JOIN tb_permissao_ponto AS pmpt ON pt.id_ponto = pmpt.id_ponto "
//                     +"INNER JOIN tb_permissao AS pm ON pmpt.id_permissao = pm.id_permissao "
//                     +"INNER JOIN tb_item_faturamento AS itf ON pm.id_permissao = itf.id_permissao "
//                     +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
//                     + "INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
//                     + "                 FROM tb_endereco_usuario "
//                     + "                 ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
//                     +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
//                     +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
//                     +"UNION "
//                     +"SELECT u.id_usuario AS userid, u.nm_usuario AS nome, u.nr_cpf_cnpj AS cpf, "
//                     +"enu.ds_endereco AS endereco, enu.ds_complemento AS complemento, enu.ds_bairro AS bairro, enu.ds_cidade AS cidade, "
//                     +"itf.id_servico AS servico, itf.id_taxa AS taxa, itf.id_acordo AS acordo, itf.id_permissao AS permissao, "
//                     +"itf.id_titulo AS titulo, tt.ds_mes_ano_competencia AS mesano, tt.dt_vencimento AS datavencimento, "
//                     +"tt.vl_titulo AS valor, tt.vl_juros AS juros, tt.vl_multa AS multa "
//                     +"FROM tb_cdc AS cdc "
//                     +"INNER JOIN tb_ponto AS pt ON cdc.id_cdc = pt.id_cdc_energia "
//                     +"INNER JOIN tb_permissao_ponto AS pmpt ON pt.id_ponto = pmpt.id_ponto "
//                     +"INNER JOIN tb_permissao AS pm ON pmpt.id_permissao = pm.id_permissao "
//                     +"INNER JOIN tb_item_faturamento AS itf ON pm.id_permissao = itf.id_permissao "
//                     +"INNER JOIN tb_usuario AS u ON pm.id_usuario_solicitante = u.id_usuario "
//                     + "INNER JOIN (SELECT DISTINCT ON (id_usuario) id_usuario, ds_endereco, ds_complemento, ds_bairro, ds_cidade "
//                     + "                 FROM tb_endereco_usuario "
//                     + "                 ORDER BY id_usuario, id_endereco_usuario DESC) AS enu ON u.id_usuario = enu.id_usuario "
//                     +"INNER JOIN tb_titulo AS tt ON itf.id_titulo = tt.id_titulo "
//                     +"WHERE ($1 = '' OR u.nr_cpf_cnpj LIKE '%' || $1 || '%') AND tt.vl_pago IS NULL "
//                     +"ORDER BY datavencimento";
    const client = await connect(); 
    const res = await client.query(query, [cpfcnpj]);
    return res.rows; 
}


module.exports = {
    selectServicosAcordosPermissionarios,
    selectContaBancaria,
    selectTaxa,
    selectFinancas,
    selectExtrato
}
