require("dotenv").config();

const db = require("./db");

const port = process.env.PORT;

const cors = require('cors');

const express = require("express");

const app = express();

app.use(express.static('public'));

app.use(express.json());

app.use(cors());

const { exec } = require('child_process');

const runCommand = (command) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(`Error: ${stderr}`);
            } else {
                resolve(stdout);
            }
        });
    });
};

const cleanCache = async () => {
    try {
        console.log('Restartando pm2...');
        await runCommand('pm2 restart all');
        console.log('pm2 restartado');

        console.log('Limpando logs do PM2...');
        await runCommand('pm2 flush');
        console.log('Logs do PM2 limpos.');

    } catch (error) {
        console.error(error);
    }
};
////////////

app.get("/relatorioArrecadacao", async (req, res) => {

    const { startDate, endDate } = req.query;

    try{
        const dados = await db.selectServicosAcordosPermissionarios( startDate, endDate );
        res.json(dados);
        cleanCache();
    } 
    catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching data' });
    }
});

// Defina suas rotas
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});


app.get("/relatorioContaBancaria", async (req, res) => {

    const { startDate, endDate } = req.query;

    try{
        const dados = await db.selectContaBancaria( startDate, endDate);
        res.json(dados);
        cleanCache();
    } 
    catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching data' });
    }
});


app.get("/relatorioTaxa", async (req, res) => {

    const { startDate, endDate, name, cpfcnpj } = req.query;

    try{
        const dados = await db.selectTaxa( startDate, endDate, name, cpfcnpj );
        res.json(dados);
        cleanCache();
    } 
    catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching data' });
    }
});


app.get("/relatorioFinanca", async (req, res) => {

    const { cpfcnpj } = req.query;

    try{
        const dados = await db.selectFinancas(cpfcnpj);
        console.log(dados);
        res.json(dados);
        cleanCache();
    } 
    catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching data' });
    }
});

app.get("/relatorioExtrato", async (req, res) => {

    const { cpfcnpj } = req.query;

    try{
        const dados = await db.selectExtrato( cpfcnpj );
        res.json(dados);
        cleanCache();
    } 
    catch (error) {
        res.status(500).json({ error: 'An error occurred while fetching data' });
    }
});


app.listen(port, () => {
    console.log(`Server listening at http://10.56.0.60:${port}`);
});

