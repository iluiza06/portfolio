// const express = require('express');
// const bodyParser = require('body-parser');
// const pool = require('./db');

// const router = express.Router();

// router.use(bodyParser.urlencoded({ extended: true }));

// // Rota para a página com o formulário
// router.get('/', (req, res) => {
//     res.sendFile(__dirname + '/index.html');
// });

// // Rota para lidar com o envio do formulário
// router.post('/servicos', async (req, res) => {
//     const { start, end } = req.body;
//     try {
//         const result = await connect();
//         const res = await result.query("SELECT to_char(tit.dt_pagamento, 'dd/mm/yyyy') AS data, u.nm_usuario AS nome, ss.ds_subgrupo_servico AS servico, sum(tit.vl_pago) AS valor FROM tb_titulo AS tit INNER JOIN tb_item_faturamento AS ifat ON ifat.id_titulo = tit.id_titulo INNER JOIN tb_servico AS s ON s.id_servico = ifat.id_servico INNER JOIN tb_subgrupo_servico AS ss ON ss.id_subgrupo_servico = s.id_subgrupo_servico INNER JOIN tb_usuario AS u ON u.id_usuario = s.id_usuario LEFT JOIN tb_grupo_receita AS gr ON gr.id_grupo_receita = ifat.id_grupo_receita LEFT JOIN tb_natureza_contabil AS nc ON nc.id_natureza_contabil = ifat.id_natureza_contabil WHERE tit.id_situacao_titulo != 1 AND tit.id_situacao_titulo != 2 AND tit.id_situacao_titulo != 8 AND tit.dt_pagamento BETWEEN $1 AND $2 AND ifat.id_tipo_lancamento IS NULL GROUP BY data, nome, servico ORDER BY data", [start, end] );
//         return res.send(result.rows);
//     } catch {
        
//     }
// });


// async function selectServicos(){
//     
//     const client = await connect();
//     // 
//     const res = await client.query("SELECT to_char(tit.dt_pagamento, 'dd/mm/yyyy') AS data, u.nm_usuario AS nome, ss.ds_subgrupo_servico AS servico, sum(tit.vl_pago) AS valor FROM tb_titulo AS tit INNER JOIN tb_item_faturamento AS ifat ON ifat.id_titulo = tit.id_titulo INNER JOIN tb_servico AS s ON s.id_servico = ifat.id_servico INNER JOIN tb_subgrupo_servico AS ss ON ss.id_subgrupo_servico = s.id_subgrupo_servico INNER JOIN tb_usuario AS u ON u.id_usuario = s.id_usuario LEFT JOIN tb_grupo_receita AS gr ON gr.id_grupo_receita = ifat.id_grupo_receita LEFT JOIN tb_natureza_contabil AS nc ON nc.id_natureza_contabil = ifat.id_natureza_contabil WHERE tit.id_situacao_titulo != 1 AND tit.id_situacao_titulo != 2 AND tit.id_situacao_titulo != 8 AND tit.dt_pagamento BETWEEN '2022-05-01' AND '2022-05-31' AND ifat.id_tipo_lancamento IS NULL GROUP BY data, nome, servico ORDER BY data");
//     return res.rows;
// }