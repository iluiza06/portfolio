--select * from tb_grupo_servico where ds_grupo_servico = 'APREENSÃO DE ANIMAL + DIÁRIA'

--select * from tb_usuario where nm_usuario = 'OSAF ORGANIZACAO DE ASSISTENCIA A FAMILIA LTDA'

--select * from tb_servico where id_usuario_cadastro = 38215

--select * from tb_servico where ds_endereco = 'DOM JOSÉ THOMAS'

--select * from tb_servico where id_servico = 56054 -- qt_unidade_cobranca = null | in_publico = N | in_isento = N

--select * from tb_servico where id_servico = 54732 -- qt_unidade_cobranca = 2.00

--select * from tb_servico where id_bairro = 26



--select * from tb_subgrupo_servico where vl_cobranca = 1.50

--select * from tb_subgrupo_servico where id_unidade_cobranca = 6;

-- select * from tb_unidade_cobranca where id_unidade_cobranca = 6

-- select * from tb_servico where ds_observacao_geral = 'MEMORANDO 93.453/2023 REFERENTE AO USO DE ESPAÇO PÚBLICO NO DIA 11 E 12 DE OUTUBRO NA PRAÇA JOSÉ THOMAS
-- '

select * from tb_faturamento where in_faturado = 'N' order by id_faturamento desc

select * from tb_item_faturamento

select * from tb_situacao_titulo

select id_titulo, id_situacao_titulo, ds_mes_ano_competencia, 
	ds_parcela, dt_baixa, dt_vencimento, dt_pagamento, vl_titulo, 
	vl_pago, id_arquivo_remessa 
	from tb_titulo 
	where dt_baixa is null and 
		dt_pagamento is null and 
		id_situacao_titulo != 1 AND 
		id_situacao_titulo != 2 AND 
		id_situacao_titulo != 8

	






select  s.id_servico, gs.ds_grupo_servico, u.nm_usuario, s.ds_endereco, s.ds_bairro, sb.vl_cobranca, uc.ds_unidade_1, us.nm_usuario,
	s.ds_observacao_geral, sb.ds_subgrupo_servico, s.dt_previsao_execucao, s.ds_complemento, s.in_publico, s.in_isento,
	s.qt_unidade_cobranca, s.dt_cadastro
	from tb_servico as s
	inner join tb_usuario as u on s.id_usuario = u.id_usuario
	inner join tb_usuario as us on s.id_usuario_cadastro = us.id_usuario
	inner join tb_subgrupo_servico as sb on s.id_subgrupo_servico = sb.id_subgrupo_servico
	inner join tb_grupo_servico as gs on sb.id_grupo_servico = gs.id_grupo_servico
	inner join tb_unidade_cobranca as uc on sb.id_unidade_cobranca = uc.id_unidade_cobranca
	where s.id_servico = 44224
	

	

-- select * from tb_servico where id_servico = 44224

-- WITH duplicates AS (
--   SELECT 
--     ctid,  -- Identificador único da linha
--     ROW_NUMBER() OVER (PARTITION BY id_grupo_servico, ds_grupo_servico, tp_grupo_servico, in_ativo ORDER BY ctid) as rnum
--   FROM 
--     tb_grupo_servico
-- )
-- SELECT 
--   ctid
-- FROM 
--   duplicates
-- WHERE 
--   rnum > 1;




-- WITH duplicates AS (
--   SELECT 
--     ctid
--   FROM (
--     SELECT 
--       ctid, 
--       ROW_NUMBER() OVER (PARTITION BY id_grupo_servico, ds_grupo_servico, tp_grupo_servico, in_ativo ORDER BY ctid) as rnum
--     FROM 
--        tb_grupo_servico
--   ) sub
--   WHERE 
--     rnum > 1
-- )
-- DELETE FROM tb_grupo_servico
-- WHERE ctid IN (SELECT ctid FROM duplicates);
