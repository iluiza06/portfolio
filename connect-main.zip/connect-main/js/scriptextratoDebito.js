function close_tab() {
  history.back();
}

function imprimir() {
  window.print();
}

///////////////////////////////////////////
function cpfCnpj(v) {
  try {
    // Remove tudo o que não é digito
    v = v.replace(/\D/g, "");

    if (v.length <= 11) {
      //CPF
      //Coloca um ponto entre o terceiro e o quarto dígitos
      v = v.replace(/(\d{3})(\d)/, "$1.$2");

      //coloca um ponto entre o terceiro e o quarto dígitos
      //de novo (para o segundo bloco de números)
      v = v.replace(/(\d{3})(\d)/, "$1.$2");

      //Coloca um hífen entre o terceiro e o quarto dígitos
      v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    } else if (v.length <= 14) {
      // CNPJ

      //Coloca ponto entre o segundo e o terceiro dígitos
      v = v.replace(/^(\d{2})(\d)/, "$1.$2");

      //Coloca ponto entre o quinto e o sexto dígitos
      v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");

      //Coloca uma barra entre o oitavo e o nono dígitos
      v = v.replace(/\.(\d{3})(\d)/, ".$1/$2");

      //Coloca um hífen depois do bloco de quatro dígitos
      v = v.replace(/(\d{4})(\d)/, "$1-$2");
    }
    return v;
  } catch (error) {
    console.error("Fetch error:", error);
    alert("Ocorreu um erro na leitura do cpf/cnpj.");
  }
}
////////////////////////////////////////

document.addEventListener("DOMContentLoaded", () => {
  //Pega as variaveis do filtro no html
  const getQuery = document.getElementById("query");
  const cpf_cnpj = document.getElementById("cpfcnpj");

  getQuery.addEventListener("click", () => {
    let thead = document.getElementById("thead");

    document.getElementById('loading').style.display = 'block';

    async function getContent() {
      thead.innerHTML = "";
      let cpfcnpj = encodeURIComponent("");

      if (cpf_cnpj.value.length == 11 || cpf_cnpj.value.length == 14) {
        cpfcnpj = encodeURIComponent(cpfCnpj(cpf_cnpj.value));
      } else {
        if (cpf_cnpj.value.length != 0) {
          alert(`O CPF DEVE CONTER 11 NUMEROS, E O CNPJ 14 NUMEROS.`);
          document.getElementById("loading").style.display = "none";
          return;
        }
      }

      // Função para validar campos cnp/cnpj
      if (cpfcnpj == '') {
        alert(' Para proseguir preencha o campo CPF/CNPJ')
        document.getElementById('loading').style.display = 'none';
        return
    }

      try {
        const response = await fetch(
          `http://10.56.0.60:3000/relatorioExtrato?cpfcnpj=${cpfcnpj}`, {
            // method: 'GET',
            // headers: {
            //     'Access-Control-Allow-Origin': 'http://10.56.0.60:3000/',
            //     'Access-Control-Allow-Methods': 'GET'
            // }
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        if(data.length == 0){
          alert('SEM DADOS PARA O CPF COLOCADO')
          document.getElementById('loading').style.display = 'none';
          return
        }
        
        console.log(data);
        show(data);
      } catch (error) {
        document.getElementById("loading").style.display = "none";
        console.error("Fetch error:", error);
        alert("Ocorreu um erro ao carregar os dados.");
      } finally {
        document.getElementById("loading").style.display = "none";
      }
    }

    getContent();
    function show(dados) {
      let calc = 0;
      let cont = 0;

      for (let dado of dados) {
        cont++;
        calc += parseFloat(dado.valor) || 0;
      }
      console.log(dados);
      thead = document.getElementById("thead");
      thead.innerHTML = "";

      let tr = thead.insertRow();

      document.getElementById("id-usuario").innerText = dados[0].userid || "";
      document.getElementById("nome-usuario").innerText = dados[0].nome || "";
      document.getElementById("cpf").innerText = dados[0].cpf || "";

      //ENDEREÇO COBRANÇA
      tr = thead.insertRow();
      let th_endCobranca = tr.insertCell();

      //Estilos
      th_endCobranca.style.fontWeight = "bold";
      th_endCobranca.colSpan = '2';
      //
      th_endCobranca.innerText = "ENDEREÇO COBRANÇA";

      //Quinta Linha
      tr = thead.insertRow();
      let th_enderecoCobranca = tr.insertCell();
      let td_enderecoCobranca = tr.insertCell();
      //Estilos
      th_enderecoCobranca.style.fontWeight = "bold";
      th_enderecoCobranca.style.paddingTop = "10px";
      td_enderecoCobranca.style.paddingTop = '10px';
      td_enderecoCobranca.colSpan= '4';

      //Recebendo dados
      th_enderecoCobranca.innerText = "Endereço Cobrança";
      td_enderecoCobranca.innerText = dados[0].endereco || "";

      //Sexta Linha
      tr = thead.insertRow();
      let th_complementoCobranca = tr.insertCell();
      let td_complementoCobranca = tr.insertCell();
      //Estilos
      th_complementoCobranca.style.fontWeight = "bold";
      td_complementoCobranca.colSpan ='2';
      //Recebendo dados
      th_complementoCobranca.innerText = "Complemento";
      td_complementoCobranca.innerText = dados[0].complemento || "";

      //Sétima Linha
      tr = thead.insertRow();
      let th_bairroCobranca = tr.insertCell();
      let td_bairroCobranca = tr.insertCell();
      //Estilos
      th_bairroCobranca.style.fontWeight = "bold";
      td_bairroCobranca.colspan ='2';
      //Recebendo dados
      th_bairroCobranca.innerText = "Bairro";
      td_bairroCobranca.innerText = dados[0].bairro || "";

      //Oitava Linha
      tr = thead.insertRow();
      let th_cidadeCobranca = tr.insertCell();
      let td_cidadeCobranca = tr.insertCell();
      //Estilos
      th_cidadeCobranca.style.fontWeight = "bold";
      td_cidadeCobranca.colspan ='2';
      //Recebendo dados
      th_cidadeCobranca.innerText = "Cidade";
      td_cidadeCobranca.innerText = dados[0].cidade || "";

      //TABELA PARA EXTRATO SIMPLES CONFERENCIA
      tr = thead.insertRow();
      let th_extratoConferencia = tr.insertCell();
      th_extratoConferencia.innerText = "EXTRATO PARA SIMPLES CONFERÊNCIA";
      th_extratoConferencia.style.fontWeight = "bold";
      th_extratoConferencia.style.padding = "40px 0px 10px 0px";
      th_extratoConferencia.colSpan ='2';

      tr = thead.insertRow();
      let th_dvComposicao = tr.insertCell();
      th_dvComposicao.innerText = "Débito Vencido ( Composição )";
      //Estilos
      th_dvComposicao.colSpan ='2';
      th_dvComposicao.style.borderBottom ='1px solid #000';
  

      //Débito Vencido Corrigido
      let th_dvCorrigido = tr.insertCell();
      th_dvCorrigido.innerText = "Débito Vencido Corrigido";
      //Estilos
      th_dvCorrigido.style.borderBottom ='1px solid #000';
      th_dvCorrigido.colSpan ='2';
      
      //Débito a Vencer
      let th_debitoaVencer = tr.insertCell();
      //Estilos
      th_debitoaVencer.style.borderBottom ='1px solid #000';
      th_debitoaVencer.colSpan ='2';
      // th_debitoaVencer.colSpan ='4';
      //Recebendo Dados
      th_debitoaVencer.innerText = "Débito a Vencer";
      //Débito Total
      let th_debitoTotal = tr.insertCell();
      //Estilos
      th_debitoTotal.style.borderBottom ='1px solid #000';
      th_debitoTotal.colSpan = '2';

      // th_debitoTotal.colSpan ='3';
    
      //Recebdno Dados
      th_debitoTotal.innerText = "Débito Total";

      //SERVIÇOS
      tr = thead.insertRow();
      let th_servicos = tr.insertCell();
      let td_servicos = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_servicos.innerText = "Serviços";
      td_servicos.innerText = dados[0].servico || "";
      //PRINCIPAL
      let th_principal = tr.insertCell();
      let td_principal = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_principal.innerText = "Principal";
      td_principal.innerText = dados[0].principal || "";
      //SERVIÇOS
      let th_servicosDv = tr.insertCell();
      let td_servicosDv = tr.insertCell();
      //Estilos
      //Recebendo Dados
      th_servicosDv.innerText = "Serviços";
      td_servicosDv.innerText = dados[0].servicosDv || "";
      //VENCIDO
      let th_vencido = tr.insertCell();
      let td_vencido = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_vencido.innerText = "Vencido";
      td_vencido.innerText = dados[0].vencido || "";

      //TAXAS
      tr = thead.insertRow();
      let th_taxas = tr.insertCell();
      let td_taxas = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_taxas.innerText = "Taxas";
      td_taxas.innerText = dados[0].taxa || "";
      //JUROS
      let th_juros = tr.insertCell();
      let td_juros = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_juros.innerText = "Juros";
      td_juros.innerText = dados[0].juros || "";
      //TAXAS
      let th_taxasDv = tr.insertCell();
      let td_taxasDv = tr.insertCell();
      //Estilos
      //Recebendo Dados
      th_taxasDv.innerText = "Taxas";
      td_taxasDv.innerText = dados[0].taxasDv || "";
      // A VENCER
      let th_aVencer = tr.insertCell();
      let td_aVencer = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_aVencer.innerText = " A Vencer";
      td_aVencer.innerText = dados[0].aVencer || "";





      //ACORDOS
      tr = thead.insertRow();
      let th_acordos = tr.insertCell();
      let td_acordos = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_acordos.innerText = "Acordos";
      td_acordos.innerText = dados[0].acordo || "";
      //MULTA
      let th_multa = tr.insertCell();
      let td_multa = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_multa.innerText = "Multa";
      td_multa.innerText = dados[0].multa || "";
      //ACORDOS
      let th_acordoDv = tr.insertCell();
      let td_acordoDv = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_acordoDv.innerText = "Acordos";
      td_acordoDv.innerText = dados[0].acordoDv || "";
      //TOTAL
      let th_totalDt = tr.insertCell();
      let td_totalDt = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_totalDt.innerText = "Total";
      td_totalDt.innerText = dados[0].totalDt || "";






      //PERMISSAO
      tr = thead.insertRow();
      let th_permissao = tr.insertCell();
      let td_permissao = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_permissao.innerText = "Permissão";
      td_permissao.innerText = dados[0].permissao || "";
      // TOTAL CORRIGIDO
      let th_totalCorrigido = tr.insertCell();
      let td_totalCorrigido = tr.insertCell();
      //Estilos
      //Recebendo Dados
      th_totalCorrigido.innerText = " Total Corrigido";
      td_totalCorrigido.innerText = dados[0].totalCorrigido || "";
      //OUTROS
      let th_outrosDv = tr.insertCell();
      let td_outrosDv = tr.insertCell();
      //Estilos
      //Recebendo Dados
      th_outrosDv.innerText = "Outros";
      td_outrosDv.innerText = dados[0].outrosDv || "";






      //AGUA
      tr = thead.insertRow();
      let th_agua = tr.insertCell();
      let td_agua = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_agua.innerText = "Água";
      td_agua.innerText = dados[0].agua || "";

      //ESSE TOTAL É DA TERCEIRA COLUNA (DEBITO A VENCER) NÃO DA SEGUNDA
      //TOTAL
      let th_totalDv = tr.insertCell();
      let td_totalDv = tr.insertCell();
      //Estilos
      //Recebendo Dados
      th_totalDv.innerText = "Total";
      td_totalDv.innerText = dados[0].totalDv || "";

      //ENERGIA
      tr = thead.insertRow();
      let th_energia = tr.insertCell();
      let td_energia = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_energia.innerText = "Energia";
      td_energia.innerText = dados[0].energia || "";

      //OUTROS
      tr = thead.insertRow();
      let th_outros = tr.insertCell();
      let td_outros = tr.insertCell();
      //Estilos
      //Recebendo dados
      th_outros.innerText = "Outros";
      td_outros.innerText = dados[0].outros || "";

      //TOTAL BASICO
      tr = thead.insertRow();
      let th_totalBasico = tr.insertCell();
      let td_totalBasico = tr.insertCell();
      //Estilos
      th_totalBasico.style.paddingBottom = '30px';
      //Recebendo Dados
      th_totalBasico.innerText = "Total Básico";
      td_totalBasico.innerText = dados[0].totalBasico || "";



      tr = thead.insertRow();
      let th_nTitulo = tr.insertCell();
      let th_mesAno = tr.insertCell();
      let th_dataVenc = tr.insertCell();
      let th_dias = tr.insertCell();
      let th_tipo = tr.insertCell();
      let th_valorPrincipal = tr.insertCell();
      let th_jurosTitulo = tr.insertCell();
      let th_multaTitulo = tr.insertCell();
      let th_total = tr.insertCell();

      th_nTitulo.innerText = "N° Título";
      th_mesAno.innerText = "Mês/Ano";
      th_dataVenc.innerText = "Data Venc";
      th_dias.innerText = "Dias";
      th_tipo.innerText = "Tipo";
      th_valorPrincipal.innerText = "Valor Principal (R$)";
      th_jurosTitulo.innerText = " Juros (R$)";
      th_multaTitulo.innerText = "Multa (R$)";
      th_total.innerText = "Total (R$)";
      
      //Estilos
      th_nTitulo.style.borderTop ='1px solid #000';
      th_nTitulo.style.borderBottom ='1px solid #000';

      th_mesAno.style.borderTop ='1px solid #000';
      th_mesAno.style.borderBottom ='1px solid #000';

      th_dataVenc.style.borderTop ='1px solid #000';
      th_dataVenc.style.borderBottom ='1px solid #000';

      th_dias.style.borderTop ='1px solid #000';
      th_dias.style.borderBottom ='1px solid #000';

      th_tipo.style.borderTop ='1px solid #000';
      th_tipo.style.borderBottom ='1px solid #000';

      th_valorPrincipal.style.borderTop ='1px solid #000';
      th_valorPrincipal.style.borderBottom ='1px solid #000';

      th_jurosTitulo.style.borderTop ='1px solid #000';
      th_jurosTitulo.style.borderBottom ='1px solid #000';

      th_multaTitulo.style.borderTop ='1px solid #000';
      th_multaTitulo.style.borderBottom ='1px solid #000';

      th_total.style.borderTop ='1px solid #000';
      th_total.style.borderBottom ='1px solid #000';
  


      for (let i = 0; i < cont; i++) {
        let tr = thead.insertRow();

        //TERCEIRA TABELA

        let td_nTitulo = tr.insertCell();
        let td_mesAno = tr.insertCell();
        let td_dataVenc = tr.insertCell();
        let td_dias = tr.insertCell();   
        let td_tipo = tr.insertCell();
        let td_valorPrincipal = tr.insertCell();
        let td_jurosTitulo = tr.insertCell();
        let td_multaTitulo = tr.insertCell();
        let td_total = tr.insertCell();
  
        //TD
        tr = thead.insertRow();
        td_nTitulo.innerText = dados[i].titulo || "";
        td_mesAno.innerText = dados[i].mesano || "";
        let td_dataVenc_temp = dados[i].datavencimento || "";
        td_dataVenc.innerText = td_dataVenc_temp.substr(8,2) + "/" + td_dataVenc_temp.substr(5,2) + "/" + td_dataVenc_temp.substr(0,4);

        td_dias.innerText = dados[i].dias || "";
        td_tipo.innerText = dados[i].tipo || "";
        td_valorPrincipal.innerText = dados[i].valorPrincipal || "";
        td_jurosTitulo.innerText = dados[i].juros || "";
        td_multaTitulo.innerText = dados[i].multa || "";
        td_total.innerText = dados[i].total || "";

      }
    }
  });
});
