function close_tab(){
    history.back();
}

function imprimir(){
    window.print();
}

// Checa se a Data Final é maior que a Data Inicial
function checarDatas() {
    let getStart = document.getElementById('start')
    let getEnd = document.getElementById('end');

    if(getEnd.value == ''){
        return
    }
    if (getStart.value > getEnd.value) {
        alert("Data do Início não pode ser maior que a data Final");
        document.getElementById('start').focus();
        return [dataStart, dataEnd];
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const getQuery = document.getElementById('query');
    const dataStart = document.getElementById('start');
    const dataEnd = document.getElementById('end');

    getQuery.addEventListener('click', () => {

        document.getElementById('loading').style.display = 'block';

        async function getContent() {
            let startDate = '';
            let endDate = '';

            //Checagem se as datas foram escolhidas nos filtros
            if(dataStart.value == ''){
                startDate = encodeURIComponent('0001-01-01');
            }
            if(dataStart.value != ''){
                startDate = encodeURIComponent(dataStart.value);
            }
            if(dataEnd.value == ''){
                const agora = new Date();
                const ano = agora.getFullYear().toString();
                const mes = String(agora.getMonth() + 1).padStart(2, '0');
                const dia = String(agora.getDate()).padStart(2, '0');
                endDate = encodeURIComponent(ano + "-" + mes + "-" + dia);
            }
            if(dataEnd.value != ''){
                endDate = encodeURIComponent(dataEnd.value);
            }

            try{
                const response = await fetch(`http://10.56.0.60:3000/relatorioArrecadacao?startDate=${startDate}&endDate=${endDate}`, {
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                const data = await response.json();
                if(data.length == 0){
                    alert('SEM DADOS PARA A DATA UTILIZADA')
                    document.getElementById('loading').style.display = 'none';
                    return
                }

                console.log(data);
                show(data);
            }
            catch (error) {
                document.getElementById('loading').style.display = 'none';
                console.error('Fetch error:', error);
                alert('Ocorreu um erro ao carregar os dados.');
            }
            finally {
                document.getElementById('loading').style.display = 'none';
            }
        }
        
        getContent();
        
        function show(dados) {
            let calc = 0;
            let cont = 0;
            let valBR = 0;
            
            for(let dado of dados ) {
                cont++;
                calc = calc + parseFloat(dado.valor) || 0;
            }            
            
            let tbody = document.getElementById('tbody');
            tbody.innerText = '';
        
            for(let i = 0; i < cont; i++){
        
                let tr = tbody.insertRow();
        
                let td_data = tr.insertCell();
                let td_receita = tr.insertCell();
                let td_valor = tr.insertCell();
        
                td_data.innerText = dados[i].data || '';
                td_data.classList.add('center');

                td_receita.innerText = dados[i].receita || '';
        
                valBR = dados[i].valor;
                valBR = valBR.replace(".", ",");
                valBR = valBR.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        
                td_valor.innerText = valBR;
                td_valor.classList.add('right');      
            }
        
            document.getElementById('subtotal').innerText = calc.toLocaleString('pt-br', {style: 'currency', currency: 'BRL'});
            document.getElementById('total').innerText = calc.toLocaleString('pt-br', {style: 'currency', currency: 'BRL'});
            document.getElementById('qtd').innerText = cont;
        }
    });
});
