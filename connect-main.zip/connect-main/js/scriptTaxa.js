function close_tab() {
    history.back();
}

function imprimir() {
    window.print();
}

// Checa se a Data Final é maior que a Data Inicial
function checarDatas() {
    let getStart = document.getElementById('start')
    let getEnd = document.getElementById('end');

    if (getEnd.value == '') {
        return
    }
    if (getStart.value > getEnd.value) {
        alert("Data do Início não pode ser maior que a data Final");
        document.getElementById('start').focus();
        return [dataStart, dataEnd];
    }
}
///////////////////////////////////
function cpfCnpj(v) {
    try {
        //Remove tudo o que não é dígito
        v = v.replace(/\D/g, "")

        if (v.length <= 11) { //CPF

            //Coloca um ponto entre o terceiro e o quarto dígitos
            v = v.replace(/(\d{3})(\d)/, "$1.$2")

            //Coloca um ponto entre o terceiro e o quarto dígitos
            //de novo (para o segundo bloco de números)
            v = v.replace(/(\d{3})(\d)/, "$1.$2")

            //Coloca um hífen entre o terceiro e o quarto dígitos
            v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2")

        } else if (v.length <= 14) { //CNPJ

            //Coloca ponto entre o segundo e o terceiro dígitos
            v = v.replace(/^(\d{2})(\d)/, "$1.$2")

            //Coloca ponto entre o quinto e o sexto dígitos
            v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")

            //Coloca uma barra entre o oitavo e o nono dígitos
            v = v.replace(/\.(\d{3})(\d)/, ".$1/$2")

            //Coloca um hífen depois do bloco de quatro dígitos
            v = v.replace(/(\d{4})(\d)/, "$1-$2")
        }
        return v
    }
    catch (error) {
        console.error('Fetch error:', error);
        alert('Ocorreu um erro na leitura do cpf/cnpj.');
    }
}
////////////////////////////////////

document.addEventListener('DOMContentLoaded', () => {
    //Pega as variaveis do filtro no html
    const getQuery = document.getElementById('query');
    const dataStart = document.getElementById('start');
    const dataEnd = document.getElementById('end');
    const nome = document.getElementById('name');
    const cpf_cnpj = document.getElementById('cpfcnpj');

    getQuery.addEventListener('click', () => {

        let thead = document.getElementById('thead');

        document.getElementById('loading').style.display = 'block';

        async function getContent() {
            thead.innerHTML = '';
            let startDate = '';
            let endDate = '';
            let name = encodeURIComponent(nome.value);
            let cpfcnpj = encodeURIComponent('');

            if (cpf_cnpj.value.length == 11 || cpf_cnpj.value.length == 14) {
                cpfcnpj = encodeURIComponent(cpfCnpj(cpf_cnpj.value));
            } else {
                if (cpf_cnpj.value.length != 0) {
                    alert(`O CPF DEVE CONTER 11 NUMEROS, E O CNPJ 14 NUMEROS.`);
                    document.getElementById('loading').style.display = 'none';
                    return
                }
            }

            //Checagem se as datas foram escolhidas nos filtros
            if (dataStart.value == '') {
                startDate = encodeURIComponent('0001-01-01');
            }
            if (dataStart.value != '') {
                startDate = encodeURIComponent(dataStart.value);
            }
            if (dataEnd.value == '') {
                const agora = new Date();
                const ano = agora.getFullYear().toString();
                const mes = String(agora.getMonth() + 1).padStart(2, '0');
                const dia = String(agora.getDate()).padStart(2, '0');
                endDate = encodeURIComponent(ano + "-" + mes + "-" + dia);
            }
            if (dataEnd.value != '') {
                endDate = encodeURIComponent(dataEnd.value);
            }
            /////////////////////////

            try {
                const response = await fetch(`http://10.56.0.60:3000/relatorioTaxa?startDate=${startDate}&endDate=${endDate}&name=${name}&cpfcnpj=${cpfcnpj}`, {
                    // method: 'GET',
                    // headers: {
                    //     'Access-Control-Allow-Origin': 'http://10.56.0.60:3000/',
                    //     'Access-Control-Allow-Methods': 'GET'
                    // }
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                const data = await response.json();
                if(data.length == 0){
                    alert('SEM DADOS PARA O FILTRO UTILIZADO')
                    document.getElementById('loading').style.display = 'none';
                    return
                }

                console.log(data);
                show(data);
            }
            catch (error) {
                document.getElementById('loading').style.display = 'none';
                console.error('Fetch error:', error);
                alert('Ocorreu um erro ao carregar os dados.');
            }
            finally {
                document.getElementById('loading').style.display = 'none';
            }
        }

        getContent();

        function show(dados) {
            let calc = 0;
            let cont = 0;

            for (let dado of dados) {
                cont++;
                calc += parseFloat(dado.valor) || 0;
            }

            // let tbody = document.getElementById('tbody');
            // tbody.innerHTML = '';

            // for(let i = 0; i < cont; i++){
            //     let tr = tbody.insertRow();

            //     let cells = [
            //         'numerotaxa', 'descricao', 'nomesolicitante', 'endereco', 'bairro',
            //         'valor', 'descricaounidade', 'nomeapontador', 'obs', 'descricaosub',
            //         'data', 'complemento', 'publico', 'isento', 'quantidade', 'datacadastro'
            //     ];

            //     cells.forEach(cell => {
            //         let td = tr.insertCell();
            //         td.innerText = dados[i][cell] || ''; 
            //     });
            // }

            let thead = document.getElementById('thead');
            thead.innerHTML = '';

            for (let i = 0; i < cont; i++) {
                let tr = thead.insertRow();

                // Primeira linha
                let th_nrTaxa = tr.insertCell();
                let td_numerotaxa = tr.insertCell();
                // Estilos
                th_nrTaxa.style.background = '#1a2d63';
                td_numerotaxa.style.background = '#1a2d63'
                td_numerotaxa.style.color = "#fff"
                th_nrTaxa.style.color = "#fff"
                td_numerotaxa.colSpan = 5;
                // Recebendo Dados 
                th_nrTaxa.innerText = 'Nr.da Taxa:';
                td_numerotaxa.innerText = dados[i].numerotaxa || '';
                ///////////////////////////////////

                // Segunda linha
                tr = thead.insertRow();
                let th_grupo = tr.insertCell();
                let td_descricao = tr.insertCell();
                let th_item = tr.insertCell();
                let td_descricaosub = tr.insertCell();
                // Estilos
                td_descricaosub.colSpan = 3;
                th_grupo.style.borderBottom = '1px solid black'
                td_descricao.style.borderBottom = '1px solid black'
                th_item.style.borderBottom = '1px solid black'
                td_descricaosub.style.borderBottom = '1px solid black'
                // Recebendo Dados 
                th_grupo.innerText = 'Grupo:';
                td_descricao.innerText = dados[i].descricao || '';
                th_item.innerText = 'Item:';
                td_descricaosub.innerText = dados[i].descricaosub || '';
                ///////////////////////////

                // Terceira linha
                tr = thead.insertRow();
                let th_usuario = tr.insertCell();
                let td_nomesolicitante = tr.insertCell();
                // Estilos
                td_nomesolicitante.colSpan = 5;
                th_usuario.style.borderBottom = '1px solid black'
                td_nomesolicitante.style.borderBottom = '1px solid black'
                //Recebendo Dados
                th_usuario.innerText = 'Usuário';
                td_nomesolicitante.innerText = dados[i].nomesolicitante || '';
                ///////////////////////////////

                // Quarta linha
                tr = thead.insertRow();
                let th_endereco = tr.insertCell();
                let td_endereco = tr.insertCell();
                let th_complemento = tr.insertCell();
                let td_complemento = tr.insertCell();
                //Estilos
                td_complemento.colSpan = 3;
                th_endereco.style.borderBottom = '1px solid black'
                td_endereco.style.borderBottom = '1px solid black'
                th_complemento.style.borderBottom = '1px solid black'
                td_complemento.style.borderBottom = '1px solid black'
                // Recebendo Dados
                th_endereco.innerText = 'Endereço';
                td_endereco.innerText = dados[i].endereco || '';
                th_complemento.innerText = 'Complemento';
                td_complemento.innerText = dados[i].complemento || '';
                /////////////////////////////

                // Quinta linha 
                tr = thead.insertRow();
                let th_bairro = tr.insertCell();
                let td_bairro = tr.insertCell();
                let th_isento = tr.insertCell();
                let td_isento = tr.insertCell();
                let th_publico = tr.insertCell();
                let td_publico = tr.insertCell();

                //Estilos
                th_bairro.style.borderBottom = '1px solid black'
                td_bairro.style.borderBottom = '1px solid black'
                th_isento.style.borderBottom = '1px solid black'
                td_isento.style.borderBottom = '1px solid black'
                th_publico.style.borderBottom = '1px solid black'
                td_publico.style.borderBottom = '1px solid black'
                // Recebendo Dados
                th_bairro.innerText = 'Bairro';
                td_bairro.innerText = dados[i].bairro || '';
                th_isento.innerText = 'Isento';
                td_isento.innerText = dados[i].isento || '';
                th_publico.innerText = 'Público';
                td_publico.innerText = dados[i].publico || '';
                ///////////////////////////

                // Sexta Linha 
                tr = thead.insertRow();
                let th_quantidade = tr.insertCell();
                let td_quantidade = tr.insertCell();
                let th_descricaounidade = tr.insertCell();
                let td_descricaounidade = tr.insertCell();
                // Estilos
                td_descricaounidade.colSpan = 3;
                th_quantidade.style.borderBottom = '1px solid black'
                td_quantidade.style.borderBottom = '1px solid black'
                th_descricaounidade.style.borderBottom = '1px solid black'
                td_descricaounidade.style.borderBottom = '1px solid black'
                // Recebendo Dados
                th_quantidade.innerText = 'Qtde Unidade de Cobrança';
                td_quantidade.innerText = dados[i].quantidade || '';
                th_descricaounidade.innerText = 'Unidade Cobrança';
                const temp_valor =  dados[i].valor;
                td_descricaounidade.innerText = temp_valor + " " + dados[i].descricaounidade || '';
                /////////////////

                // Setima Linha 
                tr = thead.insertRow();
                let th_valorTotal = tr.insertCell();
                let td_valorTotal = tr.insertCell();
                //Estilos
                td_valorTotal.colSpan = 5;
                th_valorTotal.style.borderBottom = '1px solid black'
                td_valorTotal.style.borderBottom = '1px solid black'
                // Recebendo Dados
                th_valorTotal.innerText = 'Valor Total';
                const temp_valorTotal = dados[i].valortitulo;
                td_valorTotal.innerText = temp_valorTotal || '';
                //////////////////////////////

                // Oitava Linha
                tr = thead.insertRow();
                let th_valorPago = tr.insertCell();
                let td_valorPago = tr.insertCell();

                // Estilos
                th_valorPago.style.borderBottom = '1px solid black'
                td_valorPago.style.borderBottom = '1px solid black'


                let pago = dados[i].valorpago || '';
                if (pago != "") {
                    pago = 'Sim'
                } else {
                    pago = 'Não'
                }
                th_valorPago.innerText = 'Pagou?';
                td_valorPago.innerText = pago;

                let th_data = tr.insertCell();
                let td_data = tr.insertCell();
                //Estilos
                td_data.colSpan = 3;
                th_data.style.borderBottom = '1px solid black'
                td_data.style.borderBottom = '1px solid black'
                //Recebendo Dados
                th_data.innerText = 'Cancelamento';
                td_data.innerText = dados[i].data || '';

                // Nono Linha 
                tr = thead.insertRow();
                let th_nomeapontador = tr.insertCell();
                let td_nomeapontador = tr.insertCell();
                let th_datacadastro = tr.insertCell();
                let td_datacadastro = tr.insertCell();
                // Estilos
                td_datacadastro.colSpan = 3;
                th_nomeapontador.style.borderBottom = '1px solid black'
                td_nomeapontador.style.borderBottom = '1px solid black'
                th_datacadastro.style.borderBottom = '1px solid black'
                td_datacadastro.style.borderBottom = '1px solid black'
                // recebendo Dados
                th_nomeapontador.innerText = 'Apontador';
                td_nomeapontador.innerText = dados[i].nomeapontador || '';
                th_datacadastro.innerText = 'Apontamento';
                td_datacadastro.innerText = formatarData(dados[i].datacadastro) || '';
                //////////////////////////

                // // Decima Linha 
                // tr = thead.insertRow();
                // let th_usuarioFinalizacao = tr.insertCell();
                // let td_usuarioFinalizacao = tr.insertCell();
                // let th_apontador = tr.insertCell();
                // let td_apontador = tr.insertCell();
                // let th_datacadastro1 = tr.insertCell();
                // let td_datacadastro1 = tr.insertCell();
                // // Estilos
                // td_datacadastro1.colSpan = 3;
                // th_usuarioFinalizacao.style.borderBottom = '1px solid black'
                // td_usuarioFinalizacao.style.borderBottom = '1px solid black'
                // th_apontador.style.borderBottom = '1px solid black'
                // td_apontador.style.borderBottom = '1px solid black'
                // th_datacadastro1.style.borderBottom = '1px solid black'
                // td_datacadastro1.style.borderBottom = '1px solid black'
                // // Recebendo Dados
                // th_usuarioFinalizacao.innerText = 'Usuário Finalização';
                // td_usuarioFinalizacao.innerText = dados[i].apontador || '';
                // th_apontador.innerText = 'Apontador';
                // td_apontador.innerText = dados[i].nomeapontador || '';
                // th_datacadastro1.innerText = 'Data Finalização';
                // td_datacadastro1.innerText = formatarData(dados[i].datafinalizacao) || '';
                /////////////////////////

                //Decima primeira Linha
                tr = thead.insertRow();

                let th_obs = tr.insertCell();
                let td_obs = tr.insertCell();

                td_obs.colSpan = 5;

                th_obs.innerText = 'Observação Geral';
                td_obs.innerText = dados[i].obs || '';

                // 
                tr = thead.insertRow();

                tr.classList.add('page-break');


            }

            document.getElementById('qtd').innerText = cont;
        }

        function formatarData(dataISO) {
            const data = new Date(dataISO);

            // Obtém o ano, mês e dia
            const ano = data.getFullYear();
            const mes = String(data.getMonth() + 1).padStart(2, '0'); // Meses começam em 0
            const dia = String(data.getDate()).padStart(2, '0');

            // Obtém a hora, minuto e segundo
            const hora = String(data.getHours()).padStart(2, '0');
            const minuto = String(data.getMinutes()).padStart(2, '0');
            const segundo = String(data.getSeconds()).padStart(2, '0');

            // Formata a data no formato desejado
            return `${dia}/${mes}/${ano} ${hora}:${minuto}:${segundo}`;
        }

    });
});