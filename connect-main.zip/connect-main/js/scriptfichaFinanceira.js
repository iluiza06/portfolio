function close_tab() {
    history.back();
}

function imprimir() {
    window.print();
}

function cpfCnpj(v) {
    console.log(v)
    try {
        v = v.replace(/\D/g, "")

        if (v.length <= 11) {

            v = v.replace(/(\d{3})(\d)/, "$1.$2")

            v = v.replace(/(\d{3})(\d)/, "$1.$2")

            v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2")
        } else if (v.length <= 14) {

            v = v.replace(/^(\d{2})(\d)/, "$1.$2")

            v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")

            v = v.replace(/\.(\d{3})(\d)/, ".$1/$2")

            v = v.replace(/(\d{4})(\d)/, "$1-$2")
        }
        return v

    } catch (error) {
        console.error('Fetch error:', error);
        alert('Ocorreu um erro na leitura do cpf/cnpj.');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const getQuery = document.getElementById('query');
    const cpf_cnpj = document.getElementById('cpfcnpj');

    getQuery.addEventListener('click', () => {

        let thead = document.getElementById('thead');

        document.getElementById('loading').style.display = 'block';

        async function getContent() {
            thead.innerHTML = '';
            let cpfcnpj = encodeURIComponent('');

            if (cpf_cnpj.value.length == 11 || cpf_cnpj.value.length == 14) {
                cpfcnpj = encodeURIComponent(cpfCnpj(cpf_cnpj.value));
            } else {
                if (cpf_cnpj.value.length != 0) {
                    alert(`O CPF DEVE CONTER 11 NUMEROS, E O CNPJ 14 NUMEROS.`);
                    document.getElementById('loading').style.display = 'none';
                    return
                }
            }

            // Função para validar campos cnp/cnpj
            if (cpfcnpj == '') {
                alert(' Para proseguir preencha o campo CPF/CNPJ')
                document.getElementById('loading').style.display = 'none';
                return
            }

            try {
                const response = await fetch(`http://10.56.0.60:3000/relatorioFinanca?cpfcnpj=${cpfcnpj}`, {
                    // method: 'GET',
                    // headers: {
                    //     'Access-Control-Allow-Origin': 'http://10.56.0.60:3000/',
                    //     'Access-Control-Allow-Methods': 'GET'
                    // }
                });
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }

                const data = await response.json();
                if(data.length == 0){
                    alert('SEM DADOS PARA O CPF COLOCADO')
                    document.getElementById('loading').style.display = 'none';
                    return
                }
                
                console.log(data);
                show(data);
            }
            catch (error) {
                document.getElementById('loading').style.display = 'none';
                console.error('Fetch error:', error);
                alert('Ocorreu um erro ao carregar os dados.');
            }
            finally {
                document.getElementById('loading').style.display = 'none';
            }
        }
        getContent();

        function show(dados) {
            let calc = 0;
            let cont = 0;

            for (let dado of dados) {
                cont++;
                calc += parseFloat(dado.valor) || 0;
            }

            let thead = document.getElementById('thead');
            thead.innerHTML = '';

            // primeira linha
            let tr = thead.insertRow();

            let th_nome = tr.insertCell();
            let td_nome = tr.insertCell();
            let th_cpf = tr.insertCell();
            let td_cpf = tr.insertCell();

            th_nome.style.borderTop = '1px solid black';
            th_nome.style.borderLeft = '1px solid black';
            th_nome.style.borderBottom = '1px solid black';


            td_nome.style.borderTop = '1px solid black';
            td_nome.style.borderBottom = '1px solid black';

            th_cpf.style.borderTop = '1px solid black';
            th_cpf.style.borderBottom = '1px solid black';

            td_cpf.style.borderTop = '1px solid black';
            td_cpf.style.borderRight = '1px solid black';
            td_cpf.style.borderBottom = '1px solid black';
            td_cpf.colSpan = 7;
            th_nome.style.textAlign = 'center';
            th_nome.style.fontWeight = 'bold';
            th_cpf.style.fontWeight = 'bold';

            th_nome.innerText = 'Nome: ';
            td_nome.innerText = dados[0].nome || '';

            th_cpf.innerText = ' - CPF: ';
            td_cpf.innerText = dados[0].cpf || '';

            for (let i = 0; i < cont; i++) {


                // segunda linha
                tr = thead.insertRow();

                let th_numero = tr.insertCell();
                let td_numero = tr.insertCell();
                let th_multa = tr.insertCell();
                let td_multa = tr.insertCell();
                let th_parcelas = tr.insertCell();
                let td_parcelas = tr.insertCell();
                let th_vencimento = tr.insertCell();
                let td_vencimento = tr.insertCell();
                let th_data = tr.insertCell();
                let td_data = tr.insertCell();

                th_numero.style.fontWeight = 'bold';
                th_multa.style.fontWeight = 'bold';
                th_parcelas.style.fontWeight = 'bold';
                th_vencimento.style.fontWeight = 'bold';
                th_data.style.fontWeight = 'bold';

                th_numero.style.borderTop = '3px solid black';
                th_numero.style.borderLeft = '1px solid black';
                td_numero.style.borderTop = '3px solid black';
                td_numero.style.borderRight = '1px solid black';

                th_multa.style.borderTop = '3px solid black';
                td_multa.style.borderTop = '3px solid black';
                td_multa.style.borderRight = '1px solid black';

                th_parcelas.style.borderTop = '3px solid black';
                td_parcelas.style.borderTop = '3px solid black';
                td_parcelas.style.borderRight = '1px solid black';

                th_vencimento.style.borderTop = '3px solid black';
                td_vencimento.style.borderTop = '3px solid black';
                td_vencimento.style.borderRight = '1px solid black';

                th_data.style.borderTop = '3px solid black';
                td_data.style.borderTop = '3px solid black';
                td_data.style.borderRight = '1px solid black';

                th_numero.innerText = 'Nr.Doc.: ';
                td_numero.innerText = dados[i].numero || '';

                th_multa.innerText = ' Multa: ';
                td_multa.innerText = dados[i].multa + '%' || '';

                th_parcelas.innerText = ' Parcelas: ';
                td_parcelas.innerText = dados[i].parcela || '';

                th_vencimento.innerText = ' Vencimento: ';
                td_vencimento.innerText = dados[i].datavencimento || '';
                
                th_vencimento.innerText = ' Vencimento: ';
                 let td_vencimento_temp = dados[i].datavencimento || '';
                 td_vencimento.innerText = td_vencimento_temp.substr(8, 2) + '/' + td_vencimento_temp.substr(5, 2) + '/' + td_vencimento_temp.substr(0, 4); 

                th_data.innerText = ' Data do Pagamento: ';
                td_data.innerText = dados[i].datapagamento || '';

                //terceira linha

                tr = thead.insertRow();

                let th_valor = tr.insertCell();
                let td_valor = tr.insertCell();
                let th_juros = tr.insertCell();
                let td_juros = tr.insertCell();
                let th_anoCompetencia = tr.insertCell();
                let td_anoCompetencia = tr.insertCell();
                let th_situacaoAtual = tr.insertCell();
                let td_situacaoAtual = tr.insertCell();
                let th_valorPago = tr.insertCell();
                let td_valorPago = tr.insertCell();

                th_valor.style.fontWeight = 'bold';
                th_juros.style.fontWeight = 'bold';
                th_anoCompetencia.style.fontWeight = 'bold';
                th_situacaoAtual.style.fontWeight = 'bold';
                th_valorPago.style.fontWeight = 'bold';

                th_valor.style.borderTop = '1px solid black';
                th_valor.style.borderLeft = '1px solid black';
                td_valor.style.borderTop = '1px solid black';
                td_valor.style.borderRight = '1px solid black';

                th_juros.style.borderTop = '1px solid black';

                td_juros.style.borderTop = '1px solid black';
                td_juros.style.borderRight = '1px solid black';

                th_anoCompetencia.style.borderTop = '1px solid black';

                td_anoCompetencia.style.borderTop = '1px solid black';
                td_anoCompetencia.style.borderRight = '1px solid black';

                th_situacaoAtual.style.borderTop = '1px solid black';
                td_situacaoAtual.style.borderTop = '1px solid black';
                td_situacaoAtual.style.borderRight = '1px solid black';

                th_valorPago.style.borderTop = '1px solid black';
                td_valorPago.style.borderTop = '1px solid black';
                td_valorPago.style.borderRight = '1px solid black';

                th_valor.innerText = ' Valor: ';
                td_valor.innerText = 'R$ ' + dados[i].valor || '';

                th_juros.innerText = ' Juros: ';
                td_juros.innerText = dados[i].juros + '%' || '';

                th_anoCompetencia.innerText = ' Ano/Competência: ';
                td_anoCompetencia.innerText = dados[i].ano_competencia || '';

                th_situacaoAtual.innerText = ' Situação Atual: ';
                td_situacaoAtual.innerText = dados[i].situacaotitulo || '';

                th_valorPago.innerText = ' valor Pago: ';
                td_valorPago.innerText = dados[i].valorpago || '';

                // quarta linha 

                tr = thead.insertRow();

                let th_nossoNumero = tr.insertCell();
                let td_nossoNumero = tr.insertCell();
                let th_banco = tr.insertCell();
                let td_banco = tr.insertCell();
                let th_agencia = tr.insertCell();
                let td_agencia = tr.insertCell();
                let th_tipo = tr.insertCell();
                let td_tipo = tr.insertCell();
                let th_conta = tr.insertCell();
                let td_conta = tr.insertCell();


                th_nossoNumero.style.fontWeight = 'bold';
                th_banco.style.fontWeight = 'bold';
                th_agencia.style.fontWeight = 'bold';
                th_tipo.style.fontWeight = 'bold';
                th_conta.style.fontWeight = 'bold';

                th_nossoNumero.style.borderTop = '1px solid black';
                th_nossoNumero.style.borderLeft = '1px solid black';
                td_nossoNumero.style.borderTop = '1px solid black';
                td_nossoNumero.style.borderRight = '1px solid black';

                th_banco.style.borderTop = '1px solid black';
                td_banco.style.borderTop = '1px solid black';
                td_banco.style.borderRight = '1px solid black';

                th_agencia.style.borderTop = '1px solid black';
                td_agencia.style.borderTop = '1px solid black';
                td_agencia.style.borderRight = '1px solid black';

                th_tipo.style.borderTop = '1px solid black';
                td_tipo.style.borderTop = '1px solid black';
                td_tipo.style.borderRight = '1px solid black';

                th_conta.style.borderTop = '1px solid black';
                td_conta.style.borderTop = '1px solid black';
                td_conta.style.borderRight = '1px solid black';

                th_nossoNumero.innerText = ' Nosso Número: ';
                td_nossoNumero.innerText = dados[i].nossonumero || '';
                th_banco.innerText = ' Banco: ';
                td_banco.innerText = dados[i].banco || '';


                let agencia_tipo = dados[i].agencia_tipo || '';


                agencia_tipo = agencia_tipo.split('/')
                th_agencia.innerText = ' Agência: ';
                td_agencia.innerText = agencia_tipo[0];
                th_tipo.innerText = ' Tipo: ';
                td_tipo.innerText = agencia_tipo[1].substr(0, 2);

                th_conta.innerText = ' Conta: ';
                td_conta.innerText = dados[i].conta || '';

                // quinta linha

                tr = thead.insertRow();

                let th_dataGeracao = tr.insertCell();
                let td_dataGeracao = tr.insertCell();
                let td_data_geracao = tr.insertCell();

                th_dataGeracao.style.fontWeight = 'bold';

                th_dataGeracao.style.borderTop = '1px solid black';
                th_dataGeracao.style.borderLeft = '1px solid black';
                th_dataGeracao.style.borderBottom = '1px solid black';
                td_dataGeracao.style.borderTop = '1px solid black';
                td_dataGeracao.style.borderBottom = '1px solid black';
               
                td_data_geracao.style.borderTop = '1px solid black';
                td_data_geracao.style.borderBottom = '1px solid black';
                td_data_geracao.style.borderRight = '1px solid black';
                

                th_dataGeracao.colSpan = 6;
                td_dataGeracao.colSpan = 3;
                


                th_dataGeracao.innerText = ' Valor: ';
                td_data_geracao.innerText =  'R$ ' + dados[i].valor  || '';
                console.log(dados[i].valor);
                let td_dataGeracao_temp = dados[i].datageracao || '';
                td_dataGeracao.innerText = td_dataGeracao_temp.substr(8, 2) + '/' + td_dataGeracao_temp.substr(5, 2) + '/' + td_dataGeracao_temp.substr(0, 4)
            }
        }
    });
});